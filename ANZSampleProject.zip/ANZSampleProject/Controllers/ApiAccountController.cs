﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using ANZSampleProject.Entity;

namespace ANZSampleProject.Controllers
{
    public class ApiAccountController : ApiController
    {
        private EFCONTEXT db = new EFCONTEXT();

        // GET: api/ApiAccount
        public IQueryable<ACCOUNT> GetACCOUNTs()
        {
            db.Configuration.ProxyCreationEnabled = false;
            return db.ACCOUNTs;
        }

        // GET: api/ApiAccount/5
        [ResponseType(typeof(ACCOUNT))]
        public async Task<IHttpActionResult> GetACCOUNT(int id)
        {
            ACCOUNT aCCOUNT = await db.ACCOUNTs.FindAsync(id);
            if (aCCOUNT == null)
            {
                return NotFound();
            }

            return Ok(aCCOUNT);
        }

        // PUT: api/ApiAccount/5
        [ResponseType(typeof(void))]
        public async Task<IHttpActionResult> PutACCOUNT(int id, ACCOUNT aCCOUNT)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != aCCOUNT.ACCOUNT_ID)
            {
                return BadRequest();
            }

            db.Entry(aCCOUNT).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ACCOUNTExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/ApiAccount
        [ResponseType(typeof(ACCOUNT))]
        public async Task<IHttpActionResult> PostACCOUNT(ACCOUNT aCCOUNT)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.ACCOUNTs.Add(aCCOUNT);
            await db.SaveChangesAsync();

            return CreatedAtRoute("DefaultApi", new { id = aCCOUNT.ACCOUNT_ID }, aCCOUNT);
        }

        // DELETE: api/ApiAccount/5
        [ResponseType(typeof(ACCOUNT))]
        public async Task<IHttpActionResult> DeleteACCOUNT(int id)
        {
            ACCOUNT aCCOUNT = await db.ACCOUNTs.FindAsync(id);
            if (aCCOUNT == null)
            {
                return NotFound();
            }

            db.ACCOUNTs.Remove(aCCOUNT);
            await db.SaveChangesAsync();

            return Ok(aCCOUNT);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool ACCOUNTExists(int id)
        {
            return db.ACCOUNTs.Count(e => e.ACCOUNT_ID == id) > 0;
        }
    }
}