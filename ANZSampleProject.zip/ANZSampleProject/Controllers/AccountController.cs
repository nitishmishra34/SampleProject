﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;
using ANZSampleProject.Entity;

namespace ANZSampleProject.Controllers
{
    public class AccountController : Controller
    {
        // GET: Account
        string SiteUrl = System.Configuration.ConfigurationManager.AppSettings["apiurl"];
        public ActionResult Index()
        {
            IEnumerable<ACCOUNT> Accounts = new List<ACCOUNT>();
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(SiteUrl);
                var responseTask = client.GetAsync("ApiAccount");
                responseTask.Wait();
                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IList<ACCOUNT>>();
                    readTask.Wait();
                    Accounts = readTask.Result;
                }
                else
                {
                    Accounts = Enumerable.Empty<ACCOUNT>();
                }
            }
            return View(Accounts);
        }

        public ActionResult Transaction(int id)
        {
            IEnumerable<ACCOUNT_TRANSACTION> accountTransactions = new List<ACCOUNT_TRANSACTION>();
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(SiteUrl);
                var responseTask = client.GetAsync("ApiAccountTransaction?AccountId=" + id);
                responseTask.Wait();
                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IList<ACCOUNT_TRANSACTION>>();
                    readTask.Wait();
                    accountTransactions = readTask.Result;
                }
                else
                {
                    accountTransactions = Enumerable.Empty<ACCOUNT_TRANSACTION>();
                }
            }
            return View(accountTransactions);
        }
    }
}