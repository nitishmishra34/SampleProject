namespace ANZSampleProject.Entity
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("ACCOUNT")]
    public partial class ACCOUNT
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public ACCOUNT()
        {
            ACCOUNT_TRANSACTION = new HashSet<ACCOUNT_TRANSACTION>();
        }

        [Key]
        public int ACCOUNT_ID { get; set; }

        [StringLength(50)]
        public string ACCOUNT_NUM { get; set; }

        [StringLength(100)]
        public string ACCOUNT_NAME { get; set; }

        [StringLength(1)]
        public string ACCOUNT_TYPE { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? BAL_DATE { get; set; }

        [StringLength(3)]
        public string CURRENCY { get; set; }

        [Column(TypeName = "money")]
        public decimal? OPEN_AVL_BAL { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ACCOUNT_TRANSACTION> ACCOUNT_TRANSACTION { get; set; }
    }
}
